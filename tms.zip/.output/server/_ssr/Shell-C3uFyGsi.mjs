import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ArrowLeft, i as Settings } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Shell-C3uFyGsi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tabs = [
	{
		to: "/",
		label: "运营总览"
	},
	{
		to: "/trucks",
		label: "运输车辆"
	},
	{
		to: "/racks",
		label: "仓储货架"
	},
	{
		to: "/parcel",
		label: "货物追踪"
	}
];
function useClock() {
	const [t, setT] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const f = () => {
			const d = /* @__PURE__ */ new Date();
			const p = (n) => String(n).padStart(2, "0");
			setT(`${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`);
		};
		f();
		const id = setInterval(f, 1e3);
		return () => clearInterval(id);
	}, []);
	return t;
}
function TopBar() {
	const t = useClock();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "relative z-20 flex h-16 items-center gap-10 px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-0.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-3 w-1 rounded bg-primary-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-4 w-1 rounded bg-primary-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-1 rounded bg-primary-foreground" })
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-base font-bold tracking-widest",
						children: "404DESIGN"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-muted-foreground",
						children: "B端可视化大屏设计"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-10",
				children: tabs.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: tab.to,
					activeOptions: { exact: true },
					className: "relative py-5 text-sm text-muted-foreground transition-colors hover:text-foreground data-[status=active]:font-semibold data-[status=active]:text-primary data-[status=active]:after:absolute data-[status=active]:after:inset-x-0 data-[status=active]:after:bottom-2 data-[status=active]:after:h-0.5 data-[status=active]:after:rounded data-[status=active]:after:bg-primary",
					children: tab.label
				}, tab.to))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center gap-8 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5 font-semibold text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-success" }), " DEMO · 演示数据"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-num text-muted-foreground",
						children: ["模拟时间 ", t]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "flex h-7 w-7 items-center justify-center rounded-lg bg-accent text-accent-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-3.5 w-3.5" })
					})
				]
			})
		]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "flex justify-between px-8 py-3 text-[10px] text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "404DESIGN · B端可视化大屏设计" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "可交互概念演示 · 所有业务指标与事件为示例数据" })]
	});
}
function PageHeader({ title, code, sub, status, extra }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between px-8 pt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-1 text-xs text-muted-foreground hover:text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3 w-3" }), " 返回运营总览"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-1 text-3xl font-bold",
				children: [
					title,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-num font-medium text-primary/70",
						children: code
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: sub
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-6 text-xs text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-success" }), status]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: extra })]
		})]
	});
}
function Card({ title, right, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `glass p-5 ${className}`,
		children: [title && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground",
				children: right
			})]
		}), children]
	});
}
function Tag({ children, tone = "success" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-md px-2 py-0.5 text-[11px] font-medium ${{
			success: "bg-success/15 text-success",
			primary: "bg-primary/10 text-primary",
			muted: "bg-muted text-muted-foreground",
			warning: "bg-warning/15 text-warning"
		}[tone]}`,
		children
	});
}
//#endregion
export { TopBar as a, Tag as i, Footer as n, PageHeader as r, Card as t };
