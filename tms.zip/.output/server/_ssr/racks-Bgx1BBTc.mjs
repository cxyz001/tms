import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { i as Tag, r as PageHeader, t as Card } from "./Shell-C3uFyGsi.mjs";
import { a as racks, i as rackCells } from "./mock-OAdZm5_5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/racks-Bgx1BBTc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var rack_default = "/assets/rack-DVl5VAxu.png";
function RacksPage() {
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [hover, setHover] = (0, import_react.useState)(null);
	const [sel, setSel] = (0, import_react.useState)(0);
	const r = racks[idx];
	const cells = rackCells(r);
	const s = cells[sel];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "智能货架",
			code: r.id,
			sub: `A 区 · 第 ${r.id.slice(2)} 排 · 3 层 × 4 格`,
			status: "正常运行",
			extra: "最近盘点 14:25"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_330px] gap-6 px-8 pt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-[10px] tracking-widest text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-num",
						children: "RACK ELEVATION / 货架正视"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "悬停查看箱内信息 · 点击打开档案" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto mt-2 w-[760px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: rack_default,
						alt: "货架正视图",
						width: 1408,
						height: 832,
						className: "w-full"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute grid grid-cols-4 grid-rows-3",
						style: {
							left: "10%",
							top: "6%",
							width: "80%",
							height: "82%"
						},
						children: cells.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onMouseEnter: () => setHover(i),
							onMouseLeave: () => setHover(null),
							onClick: () => setSel(i),
							className: `relative m-1 rounded-md transition-all ${c.empty ? "bg-card/85 backdrop-blur" : ""} ${sel === i ? "ring-2 ring-primary" : "hover:ring-2 hover:ring-primary/50"}`,
							children: [c.empty && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "空箱"
							}), hover === i && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass absolute -top-2 left-1/2 z-20 w-44 -translate-x-1/2 -translate-y-full p-3 text-left text-[11px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-num font-semibold",
										children: [
											c.code,
											" · ",
											c.status
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: c.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-muted-foreground",
										children: [
											c.pos,
											" · ",
											c.qty,
											" 件"
										]
									})
								]
							})]
						}, c.pos))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-[11px] text-muted-foreground",
					children: [
						"● 有货 ",
						r.used,
						" 箱 · ○ 空箱 ",
						r.empty,
						" 个 · 3 层 × 4 格"
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "货架状态",
				right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: "可用" }),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-num text-4xl font-bold",
						children: [r.rate, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "% 库位使用率"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-1.5 rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary",
							style: { width: `${r.rate}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 grid grid-cols-2 gap-4",
						children: [
							[
								"今日入库",
								r.inbound,
								"次"
							],
							[
								"今日出库",
								r.outbound,
								"次"
							],
							[
								"在库货箱",
								r.used,
								"箱"
							],
							[
								"预警",
								9,
								"条"
							]
						].map(([l, v, u]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: l
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-num text-2xl font-bold",
							children: [v, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-0.5 text-xs font-normal text-muted-foreground",
								children: u
							})]
						})] }, String(l)))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 rounded-xl bg-accent p-4 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-num font-semibold",
								children: [
									s.code,
									" · ",
									s.status
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-muted-foreground",
								children: [
									s.pos,
									" · ",
									s.name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground",
								children: [s.qty, " 件 · 点击货位切换"]
							})
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 gap-4 px-8 pt-4",
			children: racks.map((rk, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					setIdx(i);
					setSel(0);
				},
				className: `glass flex items-center justify-between p-4 text-left ${i === idx ? "ring-2 ring-primary" : "opacity-80"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm font-semibold",
					children: ["货架 ", rk.id]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[11px] text-muted-foreground",
					children: [
						rk.used,
						" 箱有货 · ",
						rk.empty,
						" 个空箱"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: rack_default,
					alt: "",
					className: "h-8 w-auto",
					loading: "lazy"
				})]
			}, rk.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1.6fr_1fr] gap-4 px-8 pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "库位货物",
				right: "展示部分 · 含空箱示例",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1.5",
									children: "库位"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "货箱编号" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "货物名称" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "数量" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "入库时间" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "状态" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: cells.slice(0, 4).map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: `border-t ${sel === i ? "bg-accent" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-num font-semibold",
								children: c.pos
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "font-num",
								children: c.code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: c.name }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [c.qty, " 件"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: "今日 10:46" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
								tone: c.empty ? "primary" : "success",
								children: c.status
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSel(i),
								className: "text-primary",
								children: "查看 ↗"
							}) })
						]
					}, c.pos)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "货品分布",
				children: [
					[
						"精密电子配件",
						35,
						"bg-primary"
					],
					[
						"工业传感器",
						35,
						"bg-teal"
					],
					[
						"智能控制模组",
						30,
						"bg-violet"
					]
				].map(([n, p, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-num",
							children: [p, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1.5 h-1.5 rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `h-full rounded-full ${c}`,
							style: { width: `${Number(p) * 2}%` }
						})
					})]
				}, String(n)))
			})]
		})
	] });
}
//#endregion
export { RacksPage as component };
