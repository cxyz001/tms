import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Truck, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { i as Tag, r as PageHeader, t as Card } from "./Shell-C3uFyGsi.mjs";
import { n as parcelTrack, r as parcels } from "./mock-OAdZm5_5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/parcel-Bu69koH9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var box_default = "/assets/box-NPIGV6yV.png";
function ParcelPage() {
	const [idx, setIdx] = (0, import_react.useState)(0);
	const p = parcels[idx];
	const gross = +(p.weight + 1.4).toFixed(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "货箱详情",
		code: p.id,
		sub: `${p.name} · 华东分拣批次 2026-1023-B`,
		status: p.status,
		extra: "最近扫描 14:28"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[1fr_1.05fr] gap-6 px-8 pt-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-[10px] tracking-widest text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-num",
						children: "PARCEL VIEW / 货箱外观"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
						tone: "primary",
						children: "包装完好"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-1 items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: box_default,
						alt: "货箱外观",
						width: 1024,
						height: 1024,
						className: "page-enter w-[440px] drop-shadow-2xl"
					}, p.id), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "glass absolute bottom-4 right-4 flex items-center gap-2 px-3 py-1.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-success" }), "已完成外观检测"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-between text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["BOX ID ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "font-num text-primary",
						children: p.id
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "批次 2026-1023-B" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-2 gap-3",
					children: parcels.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setIdx(i),
						className: `glass flex items-center justify-between p-3 text-left ${i === idx ? "ring-2 ring-primary" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-num text-sm font-semibold",
							children: x.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] text-muted-foreground",
							children: [
								x.status,
								" · ",
								x.qty,
								" 件"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: box_default,
							alt: "",
							className: "h-9 w-9",
							loading: "lazy"
						})]
					}, x.id))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-4",
					children: [
						[
							"箱内数量",
							p.qty,
							"件",
							"单箱标准数量"
						],
						[
							"货物净重",
							p.weight,
							"kg",
							"不含包装"
						],
						[
							"包装体积",
							.108,
							"m³",
							"60 × 40 × 45 cm"
						]
					].map(([l, v, u, d]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: l
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-num text-3xl font-bold",
							children: [v, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-0.5 text-xs font-normal text-muted-foreground",
								children: u
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: d
						})
					] }, String(l)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "货箱档案",
					right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: p.status }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-x-10 gap-y-3 text-xs",
						children: [
							["货物名称", p.name],
							["SKU / 数量", `${p.sku} / ${p.qty} 件`],
							["所属订单", p.order],
							["箱体尺寸", "60 × 40 × 45 cm"],
							["净重 / 毛重", `${p.weight} / ${gross} kg`],
							["目的站点", p.dest],
							["存储库位", p.slot],
							["温控要求", "常温"]
						].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: v
							})]
						}, k))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-2",
						children: [
							"防潮",
							"易碎",
							"向上放置"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
							tone: "primary",
							children: t
						}, t))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						title: "流转轨迹",
						right: "演示记录",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "space-y-4",
							children: parcelTrack.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mt-1 h-2.5 w-2.5 shrink-0 rounded-full ${i === 0 ? "bg-primary" : "border border-muted-foreground"}` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-num text-[11px] text-muted-foreground",
										children: s.time
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-semibold",
										children: s.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground",
										children: s.desc
									})] })
								]
							}, s.time))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							title: "包装与装载",
							right: "演示数据",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "毛重 / 承重上限"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-num",
										children: [gross, " / 30 kg"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-1.5 rounded-full bg-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full rounded-full bg-primary",
										style: { width: `${gross / 30 * 100}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-2 gap-2 text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "包装材质"
									}), "五层瓦楞纸"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "封箱方式"
									}), "十字封箱"] })]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							title: "关联作业对象",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/trucks",
								className: "flex items-center gap-3 rounded-xl bg-accent p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4 text-primary" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-semibold",
											children: "计划车辆 TRK-2048"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground",
											children: "3 号月台 · 上海 → 杭州"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "ml-auto h-4 w-4 text-primary" })
								]
							})
						})]
					})]
				})
			]
		})]
	})] });
}
//#endregion
export { ParcelPage as component };
