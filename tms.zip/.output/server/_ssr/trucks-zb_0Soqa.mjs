import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { l as Check, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { i as Tag, r as PageHeader, t as Card } from "./Shell-C3uFyGsi.mjs";
import { c as truckBoxes, l as trucks } from "./mock-OAdZm5_5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/trucks-zb_0Soqa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var truck_default = "/assets/truck-BgZJr-7e.png";
function TrucksPage() {
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [sel, setSel] = (0, import_react.useState)(null);
	const t = trucks[idx];
	const boxes = truckBoxes(t);
	const steps = [
		"车辆到位",
		"装载货物",
		"装载复核",
		"发车出库"
	];
	const stepDone = t.load === 100 ? 3 : t.load > 0 ? 1 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "运输卡车",
			code: t.id,
			sub: `03 号装卸月台 · ${t.route[0]} → ${t.route[1]} · 装载任务已完成`,
			status: t.status,
			extra: `预计 ${t.eta} 发车`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1fr_330px] gap-6 px-8 pt-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto w-full max-w-[1300px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: truck_default,
					alt: "运输卡车侧视图",
					width: 1792,
					height: 768,
					className: "w-full"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute grid grid-cols-6 grid-rows-3 gap-1",
					style: {
						left: "28.5%",
						top: "20%",
						width: "66%",
						height: "35%"
					},
					children: boxes.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSel(b.id),
						className: `flex flex-col justify-between rounded border p-1.5 text-left text-[10px] transition-all hover:-translate-y-0.5 ${!b.loaded ? "border-dashed border-border bg-muted/40 text-muted-foreground" : sel === b.id ? "border-primary bg-accent" : "border-border bg-card"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-num font-semibold",
							children: b.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: b.loaded ? `${b.weight} kg` : "待装载"
						})]
					}, b.id))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "车辆概况",
				right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: "运行中" }),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-num text-2xl font-bold",
						children: t.plate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "冷链厢式货车 · 9.6 m"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "装载进度"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-num text-primary",
							children: [t.load, "%"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex gap-1",
						children: Array.from({ length: 10 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 flex-1 rounded ${i < t.load / 10 ? "bg-primary" : "bg-muted"}` }, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 grid grid-cols-2 gap-4",
						children: [
							[
								"货箱",
								t.boxes,
								"箱"
							],
							[
								"异常货物",
								0,
								"件"
							],
							[
								"总重",
								t.weight,
								"吨"
							],
							[
								"装卸月台",
								"03",
								"号"
							]
						].map(([l, v, u]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: l
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-num text-2xl font-bold",
							children: [v, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-0.5 text-xs font-normal text-muted-foreground",
								children: u
							})]
						})] }, String(l)))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 text-sm font-semibold",
						children: "运输路线"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.route[0] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 border-t border-dashed border-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: t.route[1]
							})
						]
					}),
					sel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-xl bg-accent p-3 text-xs",
						children: [
							"已选中货箱 ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "font-num",
								children: sel
							}),
							" · 详情见下方清单"
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-4 gap-4 px-8 pt-4",
			children: trucks.map((tr, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					setIdx(i);
					setSel(null);
				},
				className: `glass flex items-center justify-between p-4 text-left ${i === idx ? "ring-2 ring-primary" : "opacity-80"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-num text-sm font-semibold",
					children: tr.id
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[11px] text-muted-foreground",
					children: [
						tr.route[1],
						" · ",
						tr.status
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: truck_default,
					alt: "",
					className: "h-8 w-auto",
					loading: "lazy"
				})]
			}, tr.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[1.6fr_1fr] gap-4 px-8 pt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "装箱清单",
				right: `共 ${t.boxes} 箱 · 展示前 4 箱`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1.5",
									children: "货箱编号"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "货物名称" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "车厢位置" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "重量" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "状态" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: boxes.slice(0, 4).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: `border-t ${sel === b.id ? "bg-accent" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-num",
								children: b.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: b.name }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: b.slot }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "font-num",
								children: [b.weight, " kg"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: b.loaded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children: "已装" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
								tone: "muted",
								children: "待装"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSel(b.id),
								className: "text-primary",
								children: "查看 ↗"
							}) })
						]
					}, b.id)) })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "任务进度",
				right: `预计 ${t.eta} 发车`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-between pt-4",
					children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `flex h-8 w-8 items-center justify-center rounded-full ${i < stepDone ? "bg-success/15 text-success" : i === stepDone ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`,
							children: i < stepDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4" })
						}), s]
					}, s))
				})
			})]
		})
	] });
}
//#endregion
export { TrucksPage as component };
