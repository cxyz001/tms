import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, c as Gauge, l as Check, n as TriangleAlert, o as Pause, r as TrendingUp, s as Package, t as Truck, u as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { t as Card } from "./Shell-C3uFyGsi.mjs";
import { o as throughput, s as todayTrend, t as activities } from "./mock-OAdZm5_5.mjs";
import { a as Bar, i as Area, n as BarChart, o as ResponsiveContainer, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-NF2CVl47.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LogisticsScene = (0, import_react.lazy)(() => import("./LogisticsScene-B-0tTDRO.mjs"));
var kpis = [
	{
		icon: TrendingUp,
		label: "准时发运率",
		value: "96.8",
		unit: "%"
	},
	{
		icon: Package,
		label: "在库货物",
		value: "8,476",
		unit: "件"
	},
	{
		icon: Truck,
		label: "作业车辆",
		value: "18",
		unit: "辆"
	},
	{
		icon: TriangleAlert,
		label: "待处理预警",
		value: "03",
		unit: "条"
	}
];
function Index() {
	const [paused, setPaused] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `operations-home relative -mt-16 min-h-[calc(100vh-2rem)] overflow-hidden pt-16 ${paused ? "scene-paused" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-background" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogisticsScene, { paused })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scene-instructions",
				children: "拖动旋转 · 滚轮缩放 · 点击设备查看详情"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dashboard-layout relative z-10 grid grid-cols-[320px_1fr_1fr] grid-rows-[auto_1fr_auto] gap-4 px-8 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-span-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-num text-[10px] font-semibold tracking-[0.3em] text-primary",
								children: "OPERATIONS CENTER / 01"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-2 text-3xl font-bold",
								children: "让每一件货物的流转清晰可见"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "华东智能物流中心 · 实时运营态势"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": paused,
								onClick: () => setPaused(!paused),
								className: "scene-control glass inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-primary",
								children: [
									paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-3.5 w-3.5" }),
									paused ? "继续场景演示" : "暂停场景演示",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-2 font-normal text-muted-foreground",
										children: "卡车 · AGV · 传送带"
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-start-1 flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							title: "今日作业概览",
							right: "模拟更新",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-num text-4xl font-bold",
									children: ["13,005 ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-normal text-muted-foreground",
										children: "件"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex justify-between text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "今日已处理货物"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-success",
										children: "↗ 12.6% 较昨日"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 h-16",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
										data: todayTrend,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
											id: "g",
											x1: "0",
											y1: "0",
											x2: "0",
											y2: "1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "0%",
												stopColor: "var(--primary)",
												stopOpacity: .3
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
												offset: "100%",
												stopColor: "var(--primary)",
												stopOpacity: 0
											})]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
											type: "monotone",
											dataKey: "v",
											stroke: "var(--primary)",
											strokeWidth: 2,
											fill: "url(#g)"
										})]
									}) })
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							title: "关键指标",
							right: "今日",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-3",
								children: kpis.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex h-7 w-7 items-center justify-center rounded-lg bg-accent text-accent-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(k.icon, { className: "h-3.5 w-3.5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: k.label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-auto font-num text-xl font-bold",
											children: [k.value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-0.5 text-xs font-normal text-muted-foreground",
												children: k.unit
											})]
										})
									]
								}, k.label))
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "dashboard-bottom col-span-3 mt-24 grid grid-cols-[320px_1.4fr_1fr] gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								title: "设备在线率",
								right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-success",
									children: "运行良好"
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-num text-5xl font-bold",
										children: ["98.2", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-lg text-muted-foreground",
											children: "%"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 h-1.5 rounded-full bg-muted",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[98.2%] rounded-full bg-primary" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-xs text-muted-foreground",
										children: "自动化设备 54 / 55 台在线"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/racks",
										className: "mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "h-3 w-3" }), "查看机器人状态 ↗"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								title: "小时吞吐趋势",
								right: "入库 / 出库",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-num text-3xl font-bold",
										children: ["2,342 ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-normal text-muted-foreground",
											children: "件 / 15:00 时段"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-semibold text-success",
										children: "+8.4%"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-36",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: throughput,
										barGap: 3,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "hour",
												axisLine: false,
												tickLine: false,
												tick: {
													fontSize: 10,
													fill: "var(--muted-foreground)"
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "in",
												fill: "var(--primary)",
												radius: [
													4,
													4,
													0,
													0
												],
												barSize: 12
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "out",
												fill: "var(--teal)",
												radius: [
													4,
													4,
													0,
													0
												],
												barSize: 12
											})
										]
									}) })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
								title: "作业动态",
								right: "模拟更新 15:00:56",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-4",
									children: activities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-num text-xs text-muted-foreground",
												children: a.time
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex h-5 w-5 items-center justify-center rounded-full bg-success/15 text-success",
												children: a.icon === "check" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-3 w-3" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-semibold",
												children: a.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: a.desc
											})] })
										]
									}, a.time))
								})
							})
						]
					})
				]
			})
		]
	});
}
//#endregion
export { Index as component };
