globalThis.__nitro_main__ = import.meta.url;
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx+unenv.mjs";
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-11-04T15:47:38.312Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-04T15:47:38.313Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/arrow-up-right-gWqlL_Pj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9c-ZLG2ZGumBYpVF4Pny84FQ0dmZJw\"",
		"mtime": "2026-11-05T05:13:48.639Z",
		"size": 156,
		"path": "../public/assets/arrow-up-right-gWqlL_Pj.js"
	},
	"/assets/mock-Dl4oFPj6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b68-XYgYtxuBkjLNcJINlPONno/DPM0\"",
		"mtime": "2026-11-05T05:13:48.639Z",
		"size": 2920,
		"path": "../public/assets/mock-Dl4oFPj6.js"
	},
	"/assets/parcel-CfiN3eWd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1583-ZsRKZZneuseYMbxax6TweylvS+k\"",
		"mtime": "2026-11-05T05:13:48.644Z",
		"size": 5507,
		"path": "../public/assets/parcel-CfiN3eWd.js"
	},
	"/assets/check-C0Y55brj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"71-5kk8WHBKXj8rMpWc4qcGxOWY1J8\"",
		"mtime": "2026-11-05T05:13:48.639Z",
		"size": 113,
		"path": "../public/assets/check-C0Y55brj.js"
	},
	"/assets/racks-DeJU5kkW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1666-MaWLtCrt/1/hU66tvaDteMeCFx4\"",
		"mtime": "2026-11-05T05:13:48.644Z",
		"size": 5734,
		"path": "../public/assets/racks-DeJU5kkW.js"
	},
	"/assets/truck-5VWbEwxf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18b-mGZQFDWgkTcAGSTYbYwsw3Wl9b0\"",
		"mtime": "2026-11-05T05:13:48.645Z",
		"size": 395,
		"path": "../public/assets/truck-5VWbEwxf.js"
	},
	"/assets/index-EhVO2SDE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5bfa2-ylW87Rr6GBvGATAwD8KWCQFYaqY\"",
		"mtime": "2026-11-05T05:13:48.639Z",
		"size": 376738,
		"path": "../public/assets/index-EhVO2SDE.js"
	},
	"/assets/styles-QYlDKD0H.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1404c-Kv1rI2dwtGB9GRJO9oRYB9jthaA\"",
		"mtime": "2026-11-05T05:13:48.647Z",
		"size": 81996,
		"path": "../public/assets/styles-QYlDKD0H.css"
	},
	"/assets/trucks-BFOmZJTQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"153e-vFeXFq1HImkpky22E8efzEPawpg\"",
		"mtime": "2026-11-05T05:13:48.645Z",
		"size": 5438,
		"path": "../public/assets/trucks-BFOmZJTQ.js"
	},
	"/assets/routes-Bq55XvVW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5fc5b-ngoqA0p4Gcwv9k4kp1mLXOj8/H0\"",
		"mtime": "2026-11-05T05:13:48.645Z",
		"size": 392283,
		"path": "../public/assets/routes-Bq55XvVW.js"
	},
	"/assets/LogisticsScene-eEgXHjYa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d06c-gLPrdUG16dScVEmwy3GQ34kecSY\"",
		"mtime": "2026-11-05T05:13:48.639Z",
		"size": 577644,
		"path": "../public/assets/LogisticsScene-eEgXHjYa.js"
	},
	"/assets/box-NPIGV6yV.png": {
		"type": "image/png",
		"etag": "\"1348a7-IVT0UObiSaQcRfP+W54Zizp0T5U\"",
		"mtime": "2026-11-05T05:13:48.646Z",
		"size": 1263783,
		"path": "../public/assets/box-NPIGV6yV.png"
	},
	"/assets/rack-DVl5VAxu.png": {
		"type": "image/png",
		"etag": "\"1794da-IaDy8NPGKtrKnTNsU3Hz4l0FaN4\"",
		"mtime": "2026-11-05T05:13:48.647Z",
		"size": 1545434,
		"path": "../public/assets/rack-DVl5VAxu.png"
	},
	"/assets/truck-BgZJr-7e.png": {
		"type": "image/png",
		"etag": "\"134ff7-bz7iQT7x28ebnjni35eHm352O0E\"",
		"mtime": "2026-11-05T05:13:48.648Z",
		"size": 1265655,
		"path": "../public/assets/truck-BgZJr-7e.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_DM0Gn9 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_DM0Gn9
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
