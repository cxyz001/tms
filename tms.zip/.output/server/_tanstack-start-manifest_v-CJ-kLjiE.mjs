//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CJ-kLjiE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/project/001/tms/src/routes/__root.tsx",
		children: [
			"/",
			"/parcel",
			"/racks",
			"/trucks"
		],
		preloads: ["/assets/index-EhVO2SDE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-EhVO2SDE.js"
		} }]
	},
	"/": {
		filePath: "D:/project/001/tms/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bq55XvVW.js",
			"/assets/arrow-up-right-gWqlL_Pj.js",
			"/assets/check-C0Y55brj.js",
			"/assets/truck-5VWbEwxf.js",
			"/assets/mock-Dl4oFPj6.js"
		]
	},
	"/parcel": {
		filePath: "D:/project/001/tms/src/routes/parcel.tsx",
		children: void 0,
		preloads: [
			"/assets/parcel-CfiN3eWd.js",
			"/assets/arrow-up-right-gWqlL_Pj.js",
			"/assets/truck-5VWbEwxf.js",
			"/assets/mock-Dl4oFPj6.js"
		]
	},
	"/racks": {
		filePath: "D:/project/001/tms/src/routes/racks.tsx",
		children: void 0,
		preloads: ["/assets/racks-DeJU5kkW.js", "/assets/mock-Dl4oFPj6.js"]
	},
	"/trucks": {
		filePath: "D:/project/001/tms/src/routes/trucks.tsx",
		children: void 0,
		preloads: [
			"/assets/trucks-BFOmZJTQ.js",
			"/assets/arrow-up-right-gWqlL_Pj.js",
			"/assets/check-C0Y55brj.js",
			"/assets/mock-Dl4oFPj6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
